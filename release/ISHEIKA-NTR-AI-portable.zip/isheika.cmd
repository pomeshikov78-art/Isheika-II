@echo off
rem Единый файл запуска «ИЩЕЙКА НТР AI». Данные — вне временного каталога SFX.
setlocal
chcp 65001 >nul
title ИЩЕЙКА НТР AI — сервер
set "ROOT=%~dp0"
set "ISHEIKA_DATA=%LOCALAPPDATA%\IsheikaNTR-AI"
if not exist "%ISHEIKA_DATA%" mkdir "%ISHEIKA_DATA%"
set "ISHEIKA_PORT=8000"
rem Порт принимается только числом: SFX дописывает свои ключи в командную строку.
rem Проверка средствами самого cmd (без findstr и внешних утилит).
rem Ветвление записано ПЛОСКО (goto), без вложенных скобок: парсер cmd в wine
rem не выполняет вложенный блок "if defined ... ( for /f ... )" и молча
rem теряет аргумент порта. Плоская форма работает и в Windows, и в wine.
set "ARG=%~1"
set "NONNUM="
if not defined ARG goto :launch
for /f "delims=0123456789" %%A in ("%ARG%") do set "NONNUM=1"
if defined NONNUM goto :launch
set "ISHEIKA_PORT=%ARG%"

:launch

echo ============================================================
echo   ИЩЕЙКА НТР AI — аналитика научно-технологического развития
echo   Данные:    %ISHEIKA_DATA%
echo   Интерфейс: http://127.0.0.1:%ISHEIKA_PORT%/
echo   Вход:      admin / dev:admin   (роли: lead, analyst, expert, observer, auditor)
echo   Остановка: Ctrl+C или закройте это окно
echo ============================================================
echo.

"%ROOT%python\python.exe" "%ROOT%app\run.py" --host 127.0.0.1 --port %ISHEIKA_PORT% --port-auto --open-browser
if errorlevel 1 goto :failed
goto :finish

:failed
echo.
echo Сервер завершился с ошибкой. Попробуйте другой порт: isheika.cmd 8080
echo.
pause

:finish
endlocal
